<?php

  // define your file path here
  $file_path = getcwd().'/data';

 ?>
