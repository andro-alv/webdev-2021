<?php
  // this is your configuration file
  // it contains information that all of your PHP pages
  // may need to access, such as the file path to the 'data'
  // directory.  this file will need to be updated when you
  // deploy your code to the server
  $file_path = '/Users/andresalvarez/Documents/MAMP/php_harry_potter_site/data';
?>
